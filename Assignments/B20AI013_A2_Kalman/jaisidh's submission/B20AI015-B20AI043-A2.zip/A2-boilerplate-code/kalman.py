from env import *
import numpy as np


class KalmanFilter:
    def __init__(self, noise_velocity, noise_position) -> None:
        # Complete this function to construct

        # Assume that nothing is known 
        # about the state of the target at this instance
        self.current_P = np.eye(6)*np.concatenate([np.ones((3, 1))*noise_position, np.ones((3, 1))*noise_velocity], axis=0)
        self.current_R = np.eye(6)*np.concatenate([np.ones((3, 1))*noise_position, np.ones((3, 1))*noise_velocity], axis=0)

        self.R = np.concatenate([
            np.concatenate([self.current_P, np.zeros_like(self.current_P)], axis=1),
            np.concatenate([np.zeros_like(self.current_R), self.current_R], axis=1),
        ], axis=0)
        self.H = np.concatenate([np.eye(6), np.eye(6)], axis=0)

        self.noise_v =noise_velocity
        self.noise_p = noise_position
        self.state_estimate = State(x = Vector3D(), v = RandomVector3D())
        self.kalman_gain = None
        # pass

    def input(self, observed_state:State, accel:numpy.ndarray, justUpdated:bool):

        # This function is executed multiple times during the reading.
        # When an observation is read, the `justUpdated` is true, otherwise it is false
        
        # accel is the acceleration(control) vector. 
        # It is dynamically obtained regardless of the state of the RADAR 
        # (i.e regardless of `justUpdated`) 

        # When `justUpdated` is false, the state is the same as the previously provided state
        # (i.e, given `observed_state` is not updated, it's the same as the previous outdated one)


        # Complete this function where current estimate of target is updated

        if justUpdated:
            # propagate
            self.state_estimate.position += observed_state.velocity
            self.state_estimate.velocity += accel

            # update
            y_matrix = np.concatenate([observed_state.position.reshape(-1, 1), observed_state.velocity.reshape(-1, 1)], axis=0)
            x_k = np.concatenate([self.state_estimate.position.reshape(-1, 1), self.state_estimate.velocity.reshape(-1, 1)], axis=0)

            self.updated_current_P_inv = self.H.T @ np.linalg.inv(self.R) @ self.H
            self.updated_current_P = np.linalg.inv(self.H.T @ np.linalg.inv(self.R) @ self.H)
            self.kalman_gain = self.updated_current_P @ np.eye(6) @ np.linalg.inv(self.current_R)

            # residue = y - Hx
            residue = y_matrix - x_k

            estimated_x_k = x_k - self.kalman_gain @ residue
            
            self.state_estimate.position = estimated_x_k[0:3, 0]
            self.state_estimate.velocity = estimated_x_k[3:, 0]
        
        else:
            # propagate
            self.state_estimate.position += observed_state.velocity
            self.state_estimate.velocity += accel
        # pass

    def get_current_estimate(self)->State:
        # Complete this function where the current state of the target is returned
        return self.state_estimate
        # pass