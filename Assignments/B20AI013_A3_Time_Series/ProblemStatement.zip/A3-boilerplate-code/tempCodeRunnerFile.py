
    plt.plot(outputs2, label=f'no MA term')